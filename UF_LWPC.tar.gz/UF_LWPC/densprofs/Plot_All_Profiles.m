
figure;

%prof = load('electr.profile1','-ASCII');
%semilogx(prof(1:end-2,2),prof(1:end-2,1));
%hold on;
%prof = load('electr.profile2','-ASCII');
%semilogx(prof(1:end-2,2),prof(1:end-2,1));
%hold on;
%prof = load('electr.profile3','-ASCII');
%semilogx(prof(1:end-2,2),prof(1:end-2,1));
%hold on;
for i = 10:50,
   prof = load(['d3_' num2str(i) '.dat'],'-ASCII');
   semilogx(prof(1:end-2,2),prof(1:end-2,1));
   hold on;
end

title('Electron Density Profiles used in HAARP Inversion');
ylabel('Altitude (km)');
xlabel('N_e (el/cm^3)');