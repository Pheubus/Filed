#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

/* this program will interactively modify an fp3 file for the 3D model */
void main()
{
  FILE *infile,*outfile;
  char infilename[70], outfilename[70];
  char dummy[2];
  float center1, center2, center3_1, center3_2, width, phase1, phase2, phase3, 
        distance1, distance2, distance3, amp1, amp2, amp3, dummy1;
  int denscode;
  char line[400];
  int k;


  center1 = 2688;
  center2 = 4830;
  center3_1 = 1260;
  center3_2 = 4870;

  denscode = 3;
  while  ( denscode <  11)
    {
         width = 100;
         while ( (center3_1 - width/2) > 0 )
		{ 
			strcpy(infilename, "nlkhe.lwpc");
			infile = fopen(infilename, "r");
			/* printf("Enter the name of the file to be made:\n");
			gets(outfilename); */
			strcpy(outfilename, "nlkhe1.lwpc");
			outfile=fopen(outfilename,"w");
			/*  printf("Enter the center of the gaussian\n");
			scanf("%f%*c",&center);*/
	                /* printf("Enter the width of the gaussian\n");
   			scanf("%f%*c", &width);
			printf("Enter the code of density profile corresponding to peak flux\n");
			scanf("%f%*c",&denscode);
			printf("%s\n","Copying initial lines");*/
			
			for (k = 0; k<2; k++)
			{
				fgets(line, 400, infile);
				printf("%s",line);
				(void)fputs(line, outfile);
			}
			fprintf(outfile, "%s\n", "/export/home/demirkol/profiles/densprofs/dens1.prof");
			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode-2), ".prof");
			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode-1), ".prof");

			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode), ".prof"); 
			fprintf(outfile, "%s\n", "/export/home/demirkol/profiles/densprofs/dens2.prof");

			for (k = 0; k<5; k++)
			{
				fgets(line, 400, infile);
			}

		        for (k = 0; k<8; k++)
		        {
				fgets(line, 400, infile);
				printf("%s",line);
				fputs(line, outfile);
		   }
		   fprintf(outfile,"%s%d%c%d%c%d%c%d%c%d%c%d\n"," ibound0 = ",
			                                        (int)(center1 - 2*width/2), ' ',
                                                    (int)(center1 - 3*2*width/8),' ',
                                                    (int)(center1 - 2*width/4),' ',
                                                    (int)(center1 + 2*width/4),' ',
                                                    (int)(center1 + 3*2*width/8),' ',
						    (int)(center1 + 2*width/2) );
                  fprintf(outfile,"%s%d%c%d%c%d%c%d%c%d%c%d\n"," ibound1 = ",
			                                        (int)(center1 - 2*width/2), ' ',
                                                    (int)(center1 - 3*2*width/8),' ',
                                                    (int)(center1 - 2*width/4),' ',
                                                    (int)(center1 + 2*width/4),' ',
                                                    (int)(center1 + 3*2*width/8),' ',
						    (int)(center1 + 2*width/2) );
		   fgets(line, 400, infile);                                     
		   fgets(line, 400, infile);                                     

		   for (k = 0; k<5; k++)
			{
				fgets(line, 400, infile);
				printf("%s", line);
				fputs(line, outfile);
			}
		   fclose(infile);
		   fclose(outfile);
		   system("more nlkhe1.lwpc");







		   /*			Now prepare the second input file */


			strcpy(infilename, "npmde.lwpc");
			infile = fopen(infilename, "r");
			/* printf("Enter the name of the file to be made:\n");
			gets(outfilename); */
			strcpy(outfilename, "npmde1.lwpc");
			outfile=fopen(outfilename,"w");
			/*  printf("Enter the center of the gaussian\n");
			scanf("%f%*c",&center);*/
	                /* printf("Enter the width of the gaussian\n");
   			scanf("%f%*c", &width);
			printf("Enter the code of density profile corresponding to peak flux\n");
			scanf("%f%*c",&denscode);
			printf("%s\n","Copying initial lines");*/
			
			for (k = 0; k<2; k++)
			{
				fgets(line, 400, infile);
				printf("%s",line);
				(void)fputs(line, outfile);
			}
			fprintf(outfile, "%s\n", "/export/home/demirkol/profiles/densprofs/dens1.prof");
			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode-2), ".prof");
			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode-1), ".prof");

			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode), ".prof"); 
			fprintf(outfile, "%s\n", "/export/home/demirkol/profiles/densprofs/dens2.prof");

			for (k = 0; k<5; k++)
			{
				fgets(line, 400, infile);
			}

		        for (k = 0; k<8; k++)
		        {
				fgets(line, 400, infile);
				printf("%s",line);
				fputs(line, outfile);
		        }
		   fprintf(outfile,"%s%d%c%d%c%d%c%d%c%d%c%d\n"," ibound0 = ",
			                                        (int)(center2 - 2*width/2), ' ',
                                                    (int)(center2 - 3*2*width/8),' ',
                                                    (int)(center2 - 2*width/4),' ',
                                                    (int)(center2 + 2*width/4),' ',
                                                    (int)(center2 + 3*2*width/8),' ',
						    (int)(center2 + 2*width/2) );
                  fprintf(outfile,"%s%d%c%d%c%d%c%d%c%d%c%d\n"," ibound1 = ",
			                                        (int)(center2 - 2*width/2), ' ',
                                                    (int)(center2 - 3*2*width/8),' ',
                                                    (int)(center2 - 2*width/4),' ',
                                                    (int)(center2 + 2*width/4),' ',
                                                    (int)(center2 + 3*2*width/8),' ',
						    (int)(center2 + 2*width/2) );
		   fgets(line, 400, infile);                                     
		   fgets(line, 400, infile);                                     

		   for (k = 0; k<5; k++)
			{
				fgets(line, 400, infile);
				printf("%s", line);
				fputs(line, outfile);
			}
		   fclose(infile);
		   fclose(outfile);
		   system("more npmde1.lwpc");		

			// Now prepare the third lwpc file

			strcpy(infilename, "naawa.lwpc");
			infile = fopen(infilename, "r");
			/* printf("Enter the name of the file to be made:\n");
			gets(outfilename); */
			strcpy(outfilename, "naawa1.lwpc");
			outfile=fopen(outfilename,"w");
			/*  printf("Enter the center of the gaussian\n");
			scanf("%f%*c",&center);*/
	                /* printf("Enter the width of the gaussian\n");
 			scanf("%f%*c", &width);
			printf("Enter the code of density profile corresponding to peak flux\n");
			scanf("%f%*c",&denscode);
			printf("%s\n","Copying initial lines");*/
			
			for (k = 0; k<2; k++)
			{
				fgets(line, 400, infile);
				printf("%s",line);
				(void)fputs(line, outfile);
			}


			fprintf(outfile, "%s\n", "/export/home/demirkol/profiles/densprofs/dens1.prof");
			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode-2), ".prof");
			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode-1), ".prof");

			fprintf(outfile, "%s%d%s\n", "/export/home/demirkol/profiles/densprofs/dens",(int)(denscode), ".prof"); 
			fprintf(outfile, "%s\n", "/export/home/demirkol/profiles/densprofs/dens2.prof");
			
			for (k = 0; k<5; k++)
			{
				fgets(line, 400, infile);
			}

		   for (k = 0; k<8; k++)
		   {
				fgets(line, 400, infile);
				printf("%s",line);
				fputs(line, outfile);
		   }
		   fprintf(outfile,"%s%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d\n"," ibound0 = ",
		                                    (int)(center3_1 - width/2), ' ',
                                                    (int)(center3_1 - 3*width/8),' ',
                                                    (int)(center3_1 - width/4),' ',
                                                    (int)(center3_1 + width/4),' ',
                                                    (int)(center3_1 + 3*width/8),' ',
				        	    (int)(center3_1 + width/2), ' ',
                                                    (int)(center3_2 - width/2), ' ',
                                                    (int)(center3_2 - 3*width/8),' ',
                                                    (int)(center3_2 - width/4),' ',
                                                    (int)(center3_2 + width/4),' ',
                                                    (int)(center3_2 + 3*width/8),' ',
				        	    (int)(center3_2 + width/2) );
		   fprintf(outfile,"%s%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d%c%d\n"," ibound1 = ",
		                                    (int)(center3_1 - width/2), ' ',
                                                    (int)(center3_1 - 3*width/8),' ',
                                                    (int)(center3_1 - width/4),' ',
                                                    (int)(center3_1 + width/4),' ',
                                                    (int)(center3_1 + 3*width/8),' ',
				        	    (int)(center3_1 + width/2), ' ',
                                                    (int)(center3_2 - width/2), ' ',
                                                    (int)(center3_2 - 3*width/8),' ',
                                                    (int)(center3_2 - width/4),' ',
                                                    (int)(center3_2 + width/4),' ',
                                                    (int)(center3_2 + 3*width/8),' ',
				        	    (int)(center3_2 + width/2) );
		   
			
		   fgets(line, 400, infile);
		   fgets(line, 400, infile);
                                                      
			for (k = 0; k<5; k++)
			{
				fgets(line, 400, infile);
				printf("%s", line);
				fputs(line, outfile);
			}
			fclose(infile);
			fclose(outfile);



	       		system("simulatemodels");
			system("more *1.lwpc");

		  



                   
			infile = fopen("dummy1.txt", "r");
			fscanf(infile, "%2c%e%e%e%e\n", &dummy, &distance1, &amp1, &phase1, &dummy1);
			fclose(infile);
			infile = fopen("dummy2.txt", "r");
			fscanf(infile, "%2c%e%e%e%e\n", &dummy, &distance2, &amp2, &phase2, &dummy1);
			fclose(infile);
			infile = fopen("dummy3.txt", "r");
			fscanf(infile, "%2c%e%e%e%e\n", &dummy, &distance3, &amp3, &phase3, &dummy1);
			fclose(infile);

			printf("Distance is %e Mm and the amplitude and phase are %e [dB] and %e degrees.\n", distance1, amp1, phase1);
			printf("Distance is %e Mm and the amplitude and phase are %e [dB] and %e degrees.\n", distance2, amp2, phase2);
			printf("Distance is %e Mm and the amplitude and phase are %e [dB] and %e degrees.\n", distance3, amp3, phase3);
			
			outfile = fopen("output2.txt", "a+");
			fprintf(outfile, "%e    %e   %e   %e   %e    %e    %f     %d\n", amp1, phase1, amp2, phase2, amp3, phase3, width, denscode);
			fclose(outfile);
			width +=300;
	   }
     denscode ++;
   }


}

