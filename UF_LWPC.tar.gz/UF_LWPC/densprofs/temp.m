
for i = 17:40,
   figure;
   prof1 = load(['d3_' num2str(i-6) '.dat'],'-ASCII');
   prof2 = load(['d3_' num2str(i-2) '.dat'],'-ASCII');
   prof3 = load(['d3_' num2str(i) '.dat'],'-ASCII');
   semilogx(prof1(1:end-2,2),prof1(1:end-2,1),prof2(1:end-2,2),prof2(1:end-2,1),prof3(1:end-2,2),prof3(1:end-2,1));
   legend(num2str(i-6),num2str(i-2),num2str(i));
   title('Electron Density Profiles used in HAARP Inversion');
   ylabel('Altitude (km)');
   xlabel('N_e (el/cm^3)');
end

