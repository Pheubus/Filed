
%prof_max = load(['d3_50.dat'],'-ASCII');
%prof_max = prof_max(1:end-2,:);
prof_min = load('electr.profile3','-ASCII');
prof_min = prof_min(1:end-2,:);
%maxdiff = prof_max(:,2)-prof_min(:,2);
%semilogx(prof_min(1:end-2,2),prof_min(1:end-2,1));
%hold on;
%for i = 10:50,
j = 1;
figure;
for i = 17:40,
   prof1 = load(['d3_' num2str(i-6) '.dat'],'-ASCII');
   prof2 = load(['d3_' num2str(i-2) '.dat'],'-ASCII');
   prof3 = load(['d3_' num2str(i) '.dat'],'-ASCII');
   prof1 = prof1(1:end-2,:);
   prof2 = prof2(1:end-2,:);
   prof3 = prof3(1:end-2,:);
   maxdiff = prof3(:,2)-prof_min(:,2);
   
   %prof = load(['d3_' num2str(i) '.dat'],'-ASCII');
   %prof = prof(1:end-2,:);
   ndiffe(:,j) = (prof1(:,2)-prof_min(:,2))./maxdiff;
   ndiffe(:,j+1) = (prof2(:,2)-prof_min(:,2))./maxdiff;
   ndiffe(:,j+2) = (prof3(:,2)-prof_min(:,2))./maxdiff;
   %   semilogx(prof(1:end-2,2),prof(1:end-2,1));
   %   hold on;
%      j = j+3;
%   figure;
%   plot((ndiffe));
%   figure;
   plot((ndiffe'));   
   hold on;
end
%title('Electron Density Profiles used in HAARP Inversion');
%ylabel('Altitude (km)');
%xlabel('N_e (el/cm^3)');