f2 = 1:.1:5;
f = 10.^f2;
fpts = 1.05:.1:5;
fpts = [0.5 fpts];
fp = 10.^fpts;
x = zeros(length(f),length(fp)+1);
for i = 1:length(f),
   for j = 1:i,
      x(i,j) = sqrt(log(fp(j)/f(i))/-3.95);
   end
end