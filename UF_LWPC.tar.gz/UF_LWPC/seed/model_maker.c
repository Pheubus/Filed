#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* this program will interactively make an fp3 file for the 3D model */

void capitalize (char* in, char* out);
void printprofs (FILE* outfile);
void getboundaries (FILE* outfile);

main()
{
  float freq,trlat,trlong,rclat,rclong,splat,splong,max_alt,r_o,x_o,y_o;
  char trans[4],filetrans[5],rec[3],filerec[5],dum3[4],dum2[3],path[70];
  int found,densnum,colfnum,i,end,add;
  FILE *infile,*outfile;
  char search[40],dum5[6],spot[6],filespot[5],yn,outfilename[70],pathid[5];
  
  printf("Enter the name of the file to be made:\n");
  gets(outfilename);
  outfile=fopen(outfilename,"w");

  printf("Enter the path for the model run (ex. /export/home/sjlt/npmpa):\n");
  gets(path);
  fprintf(outfile,"%s\n",path);

  printf("Enter the total number (including spot) of density profiles\n");
  printf("to be used (must be at least one):  ");
  printprofs(outfile);

  printf("Enter the total number (including spot) of collision frequency\n");
  printf("profiles to be used (can be zero):  ");
  printprofs(outfile);

  found=0;
  add=0;
  end=0;
  infile=fopen("/export/home/berto/seed/locations.txt","r+");

  printf("Enter the three letters for the transmitter:  ");
  gets(dum3);
  capitalize(dum3,trans);
  trans[3] = '\0';
  while((!found)&&(!end)) {
    fgets(search,40,infile);
    if (feof(infile))
      end=1;
    sscanf(search,"%s",filetrans);
    if (strlen(filetrans)==3) 
      if (!strcmp(filetrans,trans))
	found=1;
  }

  if (found) {
    sscanf(search,"%3s %f %f %f",filetrans,&freq,&trlat,&trlong);
    printf("%3s %.1f %.3f %.3f\n",filetrans,freq,trlat,trlong);
  } 
  else {
    printf("Couldn't find %3s.  Add it to the file (y/n)? ",trans);
    scanf("%c%*c",&yn);
    if (( yn == 'y') ||(yn == 'Y'))
      add=1;
    printf("Frequency? ");
    scanf("%f%*c",&freq);
    printf("Transmitter latitude? ");
    scanf("%f%*c",&trlat);
    printf("Transmitter longitude? ");
    scanf("%f%*c",&trlong);
    if (add) 
      fprintf(infile,"%3s %.1f %.3f %.3f\n",trans,freq,trlat,trlong);
    fflush(infile);
  }

  found=0;
  add=0;
  end=0;
  rewind(infile);

  printf("Enter the two letters for the receiver:  ");
  gets(dum2);
  capitalize(dum2,rec);
  rec[2] = '\0';

  while((!found)&&(!end)) {
    fgets(search,40,infile);
    if (feof(infile))
      end=1;
    sscanf(search,"%s",filerec);
    if (strlen(filerec)==2)
      if (!strcmp(filerec,rec))
	found=1;
  }  
  if (found) {
    sscanf(search,"%2s %f %f",filerec,&rclat,&rclong);
    printf("%2s %.3f %.3f\n",filerec,rclat,rclong);
  }
  else {
    printf("Couldn't find %2s.  Add it to the file (y/n)? ",rec);
    scanf("%c%*c",&yn);
    if (( yn == 'y') ||(yn == 'Y'))
      add=1;
    printf("Receiver latitude? ");
    scanf("%f%*c",&rclat);
    printf("Receiver longitude? ");
    scanf("%f%*c",&rclong);
    if (add)
      fprintf(infile,"%2s %.3f %.3f\n",rec,rclat,rclong);
  }
  strcpy(pathid,trans);
  strcat(pathid,rec);
  fprintf(outfile,"%.4s\n",pathid);
  fprintf(outfile,"%5s\n",pathid);
  fprintf(outfile," &datum\n");
  fprintf(outfile," freq=%.1f trlat=%.3f trlong=%.3f\n",freq,trlat,trlong);
  fprintf(outfile," rclat=%.3f rclong=%.3f\n",rclat,rclong);

  printf("Will you enter the spot location by x_o and y_o (y/n)? ");
  scanf("%c%*c",&yn);
  if ( (yn=='y')||(yn=='Y') ) {
    printf("Enter x_o,y_o (km): ");
    scanf("%f,%f%*c",&x_o,&y_o);
    fprintf(outfile," x_o=%.3f y_o=%.3f\n",x_o,y_o);
  }
  else {
    found=0;
    add=0;
    end=0;
    rewind(infile);

    printf("Enter the five letters for the spot: ");
    gets(dum5);
    capitalize(dum5,spot);
    spot[6] = '\0';

    while((!found)&&(!end)) {
      fgets(search,40,infile);
      if (feof(infile))
	end=1;
      sscanf(search,"%5s",filespot);
      if (!strcmp(filespot,spot))
	found=1;
    }
    if (found) {
      sscanf(search,"%5s %f %f",filespot,&splat,&splong);
      printf("%5s %.3f %.3f\n",filespot,splat,splong);
    }
    else {
      printf("Couldn't find %5s.  Add it to the file (y/n)? ",spot);
      scanf("%c%*c",&yn);
      if (( yn == 'y') ||(yn == 'Y'))
	add=1;
      printf("Spot latitude? ");
      scanf("%f%*c",&splat);
      printf("Spot longitude? ");
      scanf("%f%*c",&splong);
      if (add)
	fprintf(infile,"%5s %.3f %.3f\n",spot,splat,splong);
    }
  fprintf(outfile," splat=%.3f splong=%.3f\n",splat,splong);
  }

  printf("Enter the Full Width, Half Max of the spot (km): ");
  scanf("%f%*c",&r_o);
  r_o *= 1.20112241;

  printf("Enter max_alt (km) (<90 means exclude): ");
  scanf("%f%*c",&max_alt);
  if (max_alt > 90)
    fprintf(outfile," r_o=%.1f max_alt=%.1f\n",r_o,max_alt);
  else
    fprintf(outfile," r_o=%.1f\n",r_o);
  getboundaries(outfile);
  fprintf(outfile," &end\n");
}

void capitalize(char *in,char *out)
{
  int i, length;
  
  length = strlen(in);

  for (i = 0; i < length; i++) {
    out[i]=toupper(in[i]); 
  }
}
    
void printprofs(FILE *outfile)
{
  int numprofs,i;
  char profname[60];
  scanf("%d%*c",&numprofs);
  fprintf(outfile,"%d\n",numprofs);
  for (i=1;i<=numprofs;i++) {
    printf("Enter profile: ");
    gets(profname);
    fprintf(outfile,"%s\n",profname);
  }
}

void getboundaries(FILE *outfile)
{
  int leg,count,boundnum,densprof[30],colfprof[30];
  float bound[30];
  
  for (leg=0;leg<=2;leg++) {
    printf("Enter number of forced boundaries on leg %d: ",leg);
    scanf("%d%*c",&boundnum);
    for (count=1;count<=boundnum;count++) {
      printf("Enter gcp distance of bound %d: ",count);
      scanf("%f%*c",&bound[count]);
      printf("Enter densprof,colfprof before bound %d: ",count);
      scanf("%d,%d%*c",&densprof[count],&colfprof[count]);
    }
    printf("Enter densprof,colfprof after bound %d: ",boundnum);
    scanf("%d,%d%*c",&densprof[boundnum+1],&colfprof[boundnum+1]);
    if (boundnum!=0) {
      fprintf(outfile," IBOUND%d=",leg);
      for (count=1;count<=boundnum;count++)
	fprintf(outfile,"%.2f ",bound[count]);
      fprintf(outfile,"\n");
    }
    fprintf(outfile," insphtype%d=",leg);
    for (count=1;count<=(boundnum+1);count++)
      fprintf(outfile,"(%d,%d) ",densprof[count],colfprof[count]);
    fprintf(outfile,"\n");  
  }
  printf("Enter densprof,colfprof at center of spot ");
  scanf("%d,%d%*c",&densprof[0],&colfprof[0]);
  fprintf(outfile," spotinsph=(%d,%d)\n",densprof[0],colfprof[0]);
}


